﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace TS.Choosco.DAL
{
    public static class DataProxy
    {
        private static string _CONN_STRING = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        #region "FILL DATA TABLE"

        public static void Fill(DataTable dataTable, String procedureName)
        {
            SqlConnection connection = new SqlConnection(_CONN_STRING);
          
            SqlCommand command = new SqlCommand(procedureName, connection);
            command.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter adapter = new SqlDataAdapter();

            adapter.SelectCommand = command;
            connection.Open();
            using (SqlTransaction oTransaction = connection.BeginTransaction())
            {
                try
                {
                    adapter.SelectCommand.Transaction = oTransaction;
                    adapter.Fill(dataTable);
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                        connection.Close();
                    connection.Dispose();
                    adapter.Dispose();
                }
            }
        }

        public static void Fill(DataTable dataTable, String procedureName, SqlParameter[] parameters)
        {
            SqlConnection connection = new SqlConnection(_CONN_STRING);

            SqlCommand command = new SqlCommand(procedureName, connection);
            command.CommandType = CommandType.StoredProcedure;

            if (parameters != null)
                command.Parameters.AddRange(parameters);

            SqlDataAdapter adapter = new SqlDataAdapter();

            adapter.SelectCommand = command;
            connection.Open();
            using (SqlTransaction oTransaction = connection.BeginTransaction())
            {
                try
                {
                    adapter.SelectCommand.Transaction = oTransaction;
                    adapter.Fill(dataTable);
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                        connection.Close();
                    connection.Dispose();
                    adapter.Dispose();
                }
            }
        }

        #endregion

        #region "FILL DATASET"

        public static void Fill(DataSet dataSet, String procedureName)
        {
            SqlConnection connection = new SqlConnection(_CONN_STRING);

            SqlCommand command = new SqlCommand(procedureName, connection);
            command.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter adapter = new SqlDataAdapter();

            adapter.SelectCommand = command;
            connection.Open();
            using (SqlTransaction oTransaction = connection.BeginTransaction())
            {
                try
                {
                    adapter.SelectCommand.Transaction = oTransaction;
                    adapter.Fill(dataSet);
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                        connection.Close();
                    connection.Dispose();
                    adapter.Dispose();
                }
            }
        }

        public static void Fill(DataSet dataSet, String procedureName, SqlParameter[] parameters)
        {
            SqlConnection connection = new SqlConnection(_CONN_STRING);
            SqlCommand command = new SqlCommand(procedureName, connection);
            command.CommandType = CommandType.StoredProcedure;

            if (parameters != null)
                command.Parameters.AddRange(parameters);

            SqlDataAdapter adapter = new SqlDataAdapter();

            adapter.SelectCommand = command;
            connection.Open();
            using (SqlTransaction oTransaction = connection.BeginTransaction())
            {
                try
                {
                    adapter.SelectCommand.Transaction = oTransaction;
                    adapter.Fill(dataSet);
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                        connection.Close();
                    connection.Dispose();
                    adapter.Dispose();
                }
            }
        }

        #endregion

        #region "EXECUTE SCALAR"

        public static object ExecuteScalar(String procedureName)
        {
            SqlConnection connection = new SqlConnection(_CONN_STRING);
            SqlCommand command = new SqlCommand(procedureName, connection);

            command.CommandType = CommandType.StoredProcedure;
            object oReturnValue;
            connection.Open();
            using (SqlTransaction oTransaction = connection.BeginTransaction())
            {
                try
                {
                    command.Transaction = oTransaction;
                    oReturnValue = command.ExecuteScalar();
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                        connection.Close();
                    connection.Dispose();
                    command.Dispose();
                }
            }
            return oReturnValue;
        }

        public static object ExecuteScalar(String procedureName, SqlParameter[] parameters)
        {
            SqlConnection connection = new SqlConnection(_CONN_STRING);
            SqlCommand command = new SqlCommand(procedureName, connection);

            command.CommandType = CommandType.StoredProcedure;
            object oReturnValue;
            connection.Open();
            using (SqlTransaction oTransaction = connection.BeginTransaction())
            {
                try
                {
                    if (parameters != null)
                        command.Parameters.AddRange(parameters);

                    command.Transaction = oTransaction;
                    oReturnValue = command.ExecuteScalar();
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                        connection.Close();
                    connection.Dispose();
                    command.Dispose();
                }
            }
            return oReturnValue;
        }

        #endregion

        #region "EXECUTE NON QUERY"

        public static int ExecuteNonQuery(string procedureName)
        {
            SqlConnection connection = new SqlConnection(_CONN_STRING);
            SqlCommand command = new SqlCommand(procedureName, connection);

            command.CommandType = CommandType.StoredProcedure;
            int iReturnValue;
            connection.Open();
            using (SqlTransaction oTransaction = connection.BeginTransaction())
            {
                try
                {
                    command.Transaction = oTransaction;
                    iReturnValue = command.ExecuteNonQuery();
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                        connection.Close();
                    connection.Dispose();
                    command.Dispose();
                }
            }
            return iReturnValue;
        }

        public static int ExecuteNonQuery(string procedureName, ref SqlParameter[] parameters)
        {
            SqlConnection connection = new SqlConnection(_CONN_STRING);

            SqlCommand command = new SqlCommand(procedureName, connection);

            command.CommandType = CommandType.StoredProcedure;

            int iReturnValue;

            connection.Open();

            using (SqlTransaction oTransaction = connection.BeginTransaction())
            {
                try
                {
                    if (parameters != null)
                        command.Parameters.AddRange(parameters);

                    command.Transaction = oTransaction;
                    iReturnValue = command.ExecuteNonQuery();
                    oTransaction.Commit();
                }
                catch
                {
                    oTransaction.Rollback();
                    throw;
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                        connection.Close();
                    connection.Dispose();
                    command.Dispose();
                }
            }
            return iReturnValue;
        }

        public static SqlParameter GetParameter(string ParamName, object value, ParameterDirection direction)
        {
            SqlParameter parm = new SqlParameter(ParamName, value);
            parm.Direction = direction;
            return parm;
        }

        #endregion

    }
}
