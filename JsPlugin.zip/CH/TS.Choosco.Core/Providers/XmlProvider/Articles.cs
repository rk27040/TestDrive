﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;
using TS.Choosco.Common.Entities;


namespace TS.Choosco.Core.Providers.XmlProvider
{
    public class Articles
    {
        internal string SaveLocation = @"c:\temp\files";

        public List<Article> GetArticles()
        {
            var folder = this.SaveLocation + "posts" + Path.DirectorySeparatorChar;
            if (Directory.Exists(folder))
            {
                var articles = (from file in Directory.GetFiles(folder, "*.xml", SearchOption.TopDirectoryOnly)
                             select new FileInfo(file)
                             into info
                             select info.Name.Replace(".xml", string.Empty)
                             into id
                             select SelectPost((id))).ToList();

                articles.Sort();
                return articles;
            }

            return new List<Article>();
        }
        public void CreateArticle(Article article)
        {
            if (!Directory.Exists($"{SaveLocation}posts"))
                Directory.CreateDirectory($"{SaveLocation}posts");

            var fileName = $"{SaveLocation}posts{Path.DirectorySeparatorChar}{article.Id}_{article.UniqueId}.xml";
            var settings = new XmlWriterSettings { Indent = true };

            var ms = new MemoryStream();

            using (var writer = XmlWriter.Create(ms, settings))
            {
                writer.WriteStartDocument(true);
                writer.WriteStartElement("Article");
                writer.WriteElementString("Id", article.Id.ToString());
                writer.WriteElementString("UniqueId", article.UniqueId.ToString());

                writer.WriteElementString("Author", article.Author);
                writer.WriteElementString("ModifiedUser", article.ModifiedUser);
                writer.WriteElementString("Status", article.Status.ToString());
                writer.WriteElementString("AssignedTo", article.AssignedTo);
                writer.WriteElementString("CreatedUser", article.CreatedUser);



                writer.WriteElementString("Header", article.Header);
                writer.WriteElementString("SubHeader", article.SubHeader);
                writer.WriteElementString("Story", article.Story);

                writer.WriteElementString("FullImage", article.FullImage);
                writer.WriteElementString("MainImage", article.MainImage);
                writer.WriteElementString("OrigImage", article.OrigImage);
                writer.WriteElementString("Thumbnail", article.Thumbnail);
                writer.WriteEndElement();
            }

            using (var fs = File.Open(fileName, FileMode.Create, FileAccess.Write))
            {
                ms.WriteTo(fs);
                ms.Dispose();
            }
        }

        public Article SelectPost(string id)
        {
            var fileName = $"{SaveLocation}posts{Path.DirectorySeparatorChar}{id}.xml";
            Article article = new Article();
            var doc = new XmlDocument();
            doc.Load(fileName);

            article.Id = int.Parse(doc.SelectSingleNode("Article/Id").InnerText);
            article.UniqueId = Guid.Parse(doc.SelectSingleNode("Article/UniqueId").InnerText);

            article.Author = doc.SelectSingleNode("Article/Author").InnerText;
            article.ModifiedUser = doc.SelectSingleNode("Article/ModifiedUser").InnerText;
            article.Status = int.Parse(doc.SelectSingleNode("Article/Status").InnerText);
            article.AssignedTo = doc.SelectSingleNode("Article/AssignedTo").InnerText;
            article.CreatedUser = doc.SelectSingleNode("Article/CreatedUser").InnerText;

            article.Header = doc.SelectSingleNode("Article/Header").InnerText;
            article.SubHeader = doc.SelectSingleNode("Article/SubHeader").InnerText;
            article.Story = doc.SelectSingleNode("Article/Story").InnerText;

            article.FullImage = doc.SelectSingleNode("Article/FullImage").InnerText;
            article.MainImage = doc.SelectSingleNode("Article/MainImage").InnerText;
            article.OrigImage = doc.SelectSingleNode("Article/OrigImage").InnerText;
            article.Thumbnail = doc.SelectSingleNode("Article/Thumbnail").InnerText;

            return article;
        }


    }
}
