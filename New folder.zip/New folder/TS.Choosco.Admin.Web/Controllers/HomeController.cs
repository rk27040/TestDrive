﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using TS.Choosco.Admin.Web.Models;
using TS.Choosco.Common.Entities;

namespace TS.Choosco.Admin.Web.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            
            Article art = new Article();
            return View(art);
        }

        [HttpPost]
        public ActionResult Index(Article art1)
        {
            Article art2 = new Article();
            return View(art2);
        }
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        private void ReadContent()
        {
            WebClient wchtml = new WebClient();
            string htmlString = wchtml.DownloadString("http://www.idlebrain.com/movie/photogallery/myrasareen/index.html");
            int mastercount = 0;
            Regex regPattern = new Regex(@"http://www.idlebrain.com/movie/photogallery/myrasareen/images/(.*?)alt=""", RegexOptions.Singleline);
            MatchCollection matchImageLinks = regPattern.Matches(htmlString);

            foreach (Match img_match in matchImageLinks)
            {
                string imgurl = img_match.Groups[1].Value.ToString();
                Regex regx = new Regex("http://([\\w+?\\.\\w+])+([a-zA-Z0-9\\~\\!\\@\\#\\$\\%\\^\\&amp;\\*\\(\\)_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\'\\,]*)?",
                RegexOptions.IgnoreCase);
                MatchCollection ms = regx.Matches(imgurl);
                foreach (Match m in ms)
                {
                    Console.WriteLine("Downloading..  " + m.Value);
                    mastercount++;
                    try
                    {
                        WebClient wc = new WebClient();
                        wc.DownloadFile(m.Value, @"C:\Temp\_Images\bg_" + mastercount + ".gif");
                        Thread.Sleep(1000);
                    }
                    catch (Exception x)
                    {
                        Console.WriteLine("Failed to download image.");
                    }
                    break;
                }
            }
        }
    }
}