jQuery(function ($) {
	"use strict";

	$('#nav-toggler').on('click', function () {
		$(this).toggleClass('is-active');
		$('.sidenav-wrapper,.body-inner,.navbar.fixed-top').toggleClass('show');
		$('.overlay-black').fadeToggle();
	});
	$('#sidenav-menu').metisMenu();

	/* ----------------------------------------------------------- */
	/*  Fixed header
	/* ----------------------------------------------------------- 


	/* ----------------------------------------------------------- */
	/*  Mobile Menu
	/* ----------------------------------------------------------- */

	jQuery(".nav.navbar-nav li a").on("click", function () {
		jQuery(this).parent("li").find(".dropdown-menu").slideToggle();
		jQuery(this).find("li i").toggleClass("fa-angle-down fa-angle-up");
	});


	$('.nav-tabs[data-toggle="tab-hover"] > li > a').hover(function () {
		$(this).tab('show');
	});


	/* ----------------------------------------------------------- */
	/*  Site search
	/* ----------------------------------------------------------- */



	$('.nav-search').on('click', function () {
		$('.search-block').slideToggle(350);
	});

	$(window).scroll(function () {
		if ($(this).scrollTop() > 50) {
			$('#back-to-top').fadeIn();
		} else {
			$('#back-to-top').fadeOut();
		}
	});

	// scroll body to 0px on click
	$('#back-to-top').on('click', function () {
		$('#back-to-top').tooltip('hide');
		$('body,html').animate({
			scrollTop: 0
		}, 800);
		return false;
	});

	$('#back-to-top').tooltip('hide');


});