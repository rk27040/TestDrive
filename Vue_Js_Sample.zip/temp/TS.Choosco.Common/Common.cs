﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TS.Choosco.Common
{
    public enum ArticleStatus
    {
        None,
        Active,
        Open,
        ReadyToPublish,
        ProofReading,
        Deleted,
        Archived
    }
}
