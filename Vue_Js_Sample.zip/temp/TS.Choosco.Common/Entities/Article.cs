﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TS.Choosco.Common;

namespace TS.Choosco.Common.Entities
{
    public class Article
    {
        public int Id { get; set; }
        public Guid UniqueId { get; set; }
        public string Header { get; set; }
        public string SubHeader { get; set; }
        public string Story { get; set; }
        public string Thumbnail { get; set; }
        public string MainImage { get; set; }
        public string FullImage { get; set; }
        public ArticleStatus Status { get; set; }
        public string AssignedTo { get; set; }
        public string Author { get; set; }
        public string CreatedUser { get; set; }
        public string ModifiedUser { get; set; }
    }
}
