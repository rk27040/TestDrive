jQuery(document).ready(function() {
    "use strict";

});
/*-----------------------------------------------------------------------------------*/
/*	ISOTOPE
/*-----------------------------------------------------------------------------------*/
$(function() {
    // init Isotope
    var $container = $('.cp-gallery .isotope');

    $container.isotope({
        itemSelector: '.item',
        transitionDuration: '0.6s',
        masonry: {
            columnWidth: $container.width() / 12
        },
        layoutMode: 'masonry'
    });
   
});


$(function() {
    // init Isotope
    var $container = $('.cp-gallery-elite .isotope');

    $container.isotope({
        itemSelector: '.item',
        transitionDuration: '0.6s',
        masonry: {
            columnWidth: $container.width() / 12
        },
        layoutMode: 'masonry'
    });
   
});



$(function() {
    // init Isotope
    var $container = $('.cp-gallery-masonry .isotope');

    $container.isotope({
        itemSelector: '.item',
        transitionDuration: '0.6s',
        masonry: {
            columnWidth: $container.width() / 12
        },
        layoutMode: 'masonry'
    });
   
});



$(function() {
    // init Isotope
    var $container = $('.cp-masonry-posts .isotope');

    $container.isotope({
        itemSelector: '.item',
        transitionDuration: '0.6s',
        masonry: {
            columnWidth: $container.width() / 12
        },
        layoutMode: 'masonry'
    });
   
});



$(function() {
    // init Isotope
    var $container = $('.cp-masonry-posts-50 .isotope');

    $container.isotope({
        itemSelector: '.item',
        transitionDuration: '0.6s',
        masonry: {
            columnWidth: $container.width() / 12
        },
        layoutMode: 'masonry'
    });
   
});







/*-----------------------------------------------------------------------------------*/
/*	ISOTOPE
/*-----------------------------------------------------------------------------------*/