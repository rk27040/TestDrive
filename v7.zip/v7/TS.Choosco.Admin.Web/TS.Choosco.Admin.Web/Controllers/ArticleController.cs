﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TS.Choosco.Common;
using TS.Choosco.Common.Helpers;
using TS.Choosco.Common.Entities;
using TS.Choosco.DAL;


namespace TS.Choosco.Admin.Web.Controllers
{
    [Authorize]
    public class ArticleController : Controller
    {
        // GET: Article
        public ActionResult Create()
        {
            ViewBag.fileName = "blank_image.jpg";
            Article model = new Article();
            ArticleDB db = new ArticleDB();
            model.Statuses = db.GetArticleStatuses("14da4bda-7759-47c4-9150-c43a6883a44b");
            return View(model);
        }

        [HttpPost]
        public ActionResult UploadFile()
        {
            Guid guid = Guid.NewGuid();
            if (Request.Files.Count > 0)
            {
                try
                {
                    //  Get all files from Request object  
                    HttpFileCollectionBase files = Request.Files;
                    for (int i = 0; i < files.Count; i++)
                    {
                        //string path = AppDomain.CurrentDomain.BaseDirectory + "Uploads/";  
                        //string filename = Path.GetFileName(Request.Files[i].FileName);  

                        HttpPostedFileBase file = files[i];
                        string fname;

                        // Checking for Internet Explorer  
                        if (Request.Browser.Browser.ToUpper() == "IE" || Request.Browser.Browser.ToUpper() == "INTERNETEXPLORER")
                        {
                            string[] testfiles = file.FileName.Split(new char[] { '\\' });
                            fname = testfiles[testfiles.Length - 1];
                        }
                        else
                        {
                            fname = file.FileName;
                        }

                        // Get the complete folder path and store the file inside it.  
                        fname = Path.Combine(Server.MapPath("~/Images/"), Guid.NewGuid() + Path.GetExtension(fname));
                        file.SaveAs(fname);
                        ViewBag.fileName = fname;
                        return Json($"/Images/{Path.GetFileName(fname)}");
                    }

                    // Returns message that successfully uploaded  
                    return Json("File Uploaded Successfully");
                }
                catch (Exception ex)
                {
                    return Json("Error occurred. Error details: " + ex.Message);
                }
            }
            else
            {
                return Json("No files selected.");
            }
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddEvent(Article article)
        {
            if (article.Id == 0)
            {
                string path = Server.MapPath("~/Images");
                article.Id = 0;
                article.UniqueId = Guid.NewGuid();
                article.CreatedUser = User.Identity.Name;
                article.ModifiedUser = User.Identity.Name;
                article.Status = 1;
                string uploadedFileName = Path.Combine(path, Path.GetFileName(article.OrigImage));
                string origFileName = Path.Combine(path, article.UniqueId.ToString() + Path.GetExtension(article.OrigImage));
                System.IO.File.Move(uploadedFileName, origFileName);
                article.OrigImage = Path.GetFileName(origFileName);

                string fileName = $"{article.UniqueId}_Main.PNG";
                ImageHelper.SaveImageFromDataUrl(article.MainImage, Path.Combine(path, fileName));
                article.MainImage = fileName;

                fileName = $"{article.UniqueId}_Thumb.PNG";
                ImageHelper.SaveImageFromDataUrl(article.Thumbnail, Path.Combine(path, fileName));
                article.Thumbnail = fileName;

                fileName = $"{article.UniqueId}_Full.PNG";
                ImageHelper.SaveImageFromDataUrl(article.FullImage, Path.Combine(path, fileName));
                article.FullImage = fileName;

                ArticleDB db = new ArticleDB();
                db.SaveArticle(ref article);
            }
            //save Images
            return Json("{status:true}", JsonRequestBehavior.AllowGet);
        }

        public ActionResult Index()
        {
            MainDisplay model = new MainDisplay();
            ArticleDB db = new ArticleDB();
            model.Articles = db.GetArticle("", 50);
            model.StatusList = db.GetArticleStatuses("14da4bda-7759-47c4-9150-c43a6883a44b");
            return View(model);
        }


    }

}