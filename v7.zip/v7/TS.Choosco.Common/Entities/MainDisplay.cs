﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TS.Choosco.Common.Entities
{
    public class MainDisplay
    {
        public string UserName { get; set; }
        public List<Article> Articles { get; set; }
        public string SearchString { get; set; }
        public int RowCount { get; set; }
        public int Status { get; set; }
        public List<ArticleStatus> StatusList { get; set; }


    }
}
