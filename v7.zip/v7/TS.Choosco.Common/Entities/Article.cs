﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TS.Choosco.Common.Helpers;
using System.Data;

namespace TS.Choosco.Common.Entities
{
    public class Article
    {
        public int Id { get; set; }
        public Guid UniqueId { get; set; }
        public int Status { get; set; }
        public string Header { get; set; }
        public string SubHeader { get; set; }
        public string Story { get; set; }
        public string Thumbnail { get; set; }
        public string MainImage { get; set; }
        public string FullImage { get; set; }
        public string OrigImage { get; set; }
        public string AssignedTo { get; set; }
        public string Author { get; set; }
        public string CreatedUser { get; set; }
        public string ModifiedUser { get; set; }

        public List<ArticleStatus> Statuses { get; set; }

        public Article() { }
        public Article(DataRow row)
        {
            this.Id = DataHelper.ToInt32(row["Id"]);
            this.UniqueId =  (Guid)(row["UniqueId"]);
            this.Status = 1;//ArticleStatus.Active;// (ArticleStatus)(row["Status"]);
            this.Header = DataHelper.ToString(row["Header"]);
            this.SubHeader = DataHelper.ToString(row["SubHeader"]);
            this.Story = DataHelper.ToString(row["Story"]);
            this.Thumbnail = DataHelper.ToString(row["ThumbImage"]);
            this.MainImage = DataHelper.ToString(row["MainImage"]);
            this.FullImage = DataHelper.ToString(row["FullImage"]);
            this.OrigImage = DataHelper.ToString(row["OrigImage"]);
            this.AssignedTo = DataHelper.ToString(row["AssignedTo"]);
            this.Author = DataHelper.ToString(row["Author"]);
            this.CreatedUser = DataHelper.ToString(row["CreatedUser"]);
            this.ModifiedUser = DataHelper.ToString(row["ModifiedUsers"]);

        }
    }

    
}
