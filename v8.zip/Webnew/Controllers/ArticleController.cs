﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using TS.Choosco.Common;
using TS.Choosco.Common.Helpers;
using TS.Choosco.Common.Entities;
using TS.Choosco.DAL;
using TS.Choosco.Admin.Web.Models;


namespace TS.Choosco.Admin.Web.Controllers
{
    [Authorize]
    public class ArticleController : BaseController
    {

        public ActionResult Index()
        {
            MainDisplay model = new MainDisplay();
            ArticleDB db = new ArticleDB();
            string userName = User.IsInRole("Admin") ? null : TSLoggedInUser().UserName;
            model.Articles = db.GetArticles(userName, 50);
            model.StatusList = db.GetArticleStatuses(TSLoggedInUser().Id);
            model.Users = UserDB.GetUsersList();
            return View(model);
        }
        public ActionResult Create(string uid = null)
        {

            ArticleDB db = new ArticleDB();
            Article model;
            if (uid == null)
            {
                ViewBag.fileName = "blank_image.jpg";
                model = new Article();
                model.Id = 0;
                model.UniqueId = Guid.NewGuid();
            }
            else
            {
                model = db.GetArticle(Guid.Parse(uid));
                ViewBag.fileName = model.OrigImage;
            }
            model.Statuses = db.GetArticleStatuses(TSLoggedInUser().Id);
            return View(model);
        }

        [HttpPost]
        public ActionResult UploadFile()
        {
            Guid guid = Guid.NewGuid();
            if (Request.Files.Count > 0)
            {
                try
                {
                    //  Get all files from Request object  
                    HttpFileCollectionBase files = Request.Files;
                    for (int i = 0; i < files.Count; i++)
                    {
                        //string path = AppDomain.CurrentDomain.BaseDirectory + "Uploads/";  
                        //string filename = Path.GetFileName(Request.Files[i].FileName);  

                        HttpPostedFileBase file = files[i];
                        string fname;

                        // Checking for Internet Explorer  
                        if (Request.Browser.Browser.ToUpper() == "IE" || Request.Browser.Browser.ToUpper() == "INTERNETEXPLORER")
                        {
                            string[] testfiles = file.FileName.Split(new char[] { '\\' });
                            fname = testfiles[testfiles.Length - 1];
                        }
                        else
                        {
                            fname = file.FileName;
                        }

                        // Get the complete folder path and store the file inside it.  
                        fname = Path.Combine(Server.MapPath("~/Images/"), Guid.NewGuid() + Path.GetExtension(fname));
                        file.SaveAs(fname);
                        ViewBag.fileName = fname;
                        return Json($"/Images/{Path.GetFileName(fname)}");
                    }

                    // Returns message that successfully uploaded  
                    return Json("File Uploaded Successfully");
                }
                catch (Exception ex)
                {
                    return Json("Error occurred. Error details: " + ex.Message);
                }
            }
            else
            {
                return Json("No files selected.");
            }
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddEvent(Article article)
        {

            string path = Server.MapPath("~/Images");
            ArticleDB dbArticle = new ArticleDB();
            Article articleExisitng = dbArticle.GetArticle(article.UniqueId);

            if (articleExisitng != null && articleExisitng.Id > 0)
            {
                article.Id = articleExisitng.Id;
                article.CreatedUser = articleExisitng.CreatedUser;
                article.ModifiedUser = articleExisitng.ModifiedUser + "," + User.Identity.Name;
                article.AssignedTo = articleExisitng.AssignedTo;
            }
            else
            {
                article.CreatedUser = TSLoggedInUser().UserName;
                article.ModifiedUser = TSLoggedInUser().UserName;
                article.AssignedTo = TSLoggedInUser().UserName;
            }
            article.UniqueId = Guid.NewGuid();
            string uploadedFileName = Path.Combine(path, Path.GetFileName(article.OrigImage));
            string origFileName = Path.Combine(path, article.UniqueId.ToString() + Path.GetExtension(article.OrigImage));
            System.IO.File.Move(uploadedFileName, origFileName);
            article.OrigImage = Path.GetFileName(origFileName);

            string fileName = $"{article.UniqueId}_Main.PNG";
            ImageHelper.SaveImageFromDataUrl(article.MainImage, Path.Combine(path, fileName));
            article.MainImage = fileName;

            fileName = $"{article.UniqueId}_Thumb.PNG";
            ImageHelper.SaveImageFromDataUrl(article.Thumbnail, Path.Combine(path, fileName));
            article.Thumbnail = fileName;

            fileName = $"{article.UniqueId}_Full.PNG";
            ImageHelper.SaveImageFromDataUrl(article.FullImage, Path.Combine(path, fileName));
            article.FullImage = fileName;

            ArticleDB db = new ArticleDB();
            db.SaveArticle(ref article);


            //save Images
            return Json("{status:true}", JsonRequestBehavior.AllowGet);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult UpdateStatus(Guid identifier, int status)
        {
            ArticleDB db = new ArticleDB();
            db.SetArticleStatus(identifier, status);
            return Json("{status:true}", JsonRequestBehavior.AllowGet);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult SetAssignment(Guid identifier, string name)
        {
            ArticleDB db = new ArticleDB();
            db.SetAssgnedTo(identifier, name);
            return Json("{status:true}", JsonRequestBehavior.AllowGet);
        }

    }

}