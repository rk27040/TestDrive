﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(TS.Choosco.Admin.Web.Startup))]
namespace TS.Choosco.Admin.Web
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
