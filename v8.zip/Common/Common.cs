﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TS.Choosco.Common
{
    //public enum ArticleStatus
    //{
    //    Active = 1,
    //    Researching = 2,
    //    InProgress = 3,
    //    ReadyForProofReading = 3,
    //    ReadyToPublish= 4,
    //    Deleted = 6,
    //    Archived = 7
    //}
}
