﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TS.Choosco.Common.Entities
{
    public class ArticleStatus
    {
        public int ID { get; set; }
        public string Description  { get; set; }
    }
}
