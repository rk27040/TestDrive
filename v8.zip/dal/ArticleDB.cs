﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using TS.Choosco.Common.Entities;



namespace TS.Choosco.DAL
{
    public class ArticleDB
    {
        public void SaveArticle(ref Article article)
        {
            SqlParameter[] parms = new SqlParameter[15];

            parms[0] = DataProxy.GetParameter("@Id",article.Id, ParameterDirection.Input);
            parms[1] = DataProxy.GetParameter("@UniqueId", article.UniqueId, ParameterDirection.Input);
            parms[2] = DataProxy.GetParameter("@Header",article.Header, ParameterDirection.Input);
            parms[3] = DataProxy.GetParameter("@SubHeader", article.SubHeader, ParameterDirection.Input);
            parms[4] = DataProxy.GetParameter("@Story", article.Story, ParameterDirection.Input);
            parms[5] = DataProxy.GetParameter("@ThumbImage", article.Thumbnail, ParameterDirection.Input);
            parms[6] = DataProxy.GetParameter("@MainImage", article.MainImage, ParameterDirection.Input);
            parms[7] = DataProxy.GetParameter("@FullImage", article.FullImage, ParameterDirection.Input);
            parms[7] = DataProxy.GetParameter("@OrigImage", article.OrigImage, ParameterDirection.Input);
            parms[8] = DataProxy.GetParameter("@AssignedTo", article.AssignedTo, ParameterDirection.Input);
            parms[9] = DataProxy.GetParameter("@DateModified", DateTime.Now, ParameterDirection.Input);
            parms[10] = DataProxy.GetParameter("@Author", article.Author, ParameterDirection.Input);
            parms[11] = DataProxy.GetParameter("@Status", article.Status, ParameterDirection.Input);
            parms[12] = DataProxy.GetParameter("@CreatedUser", article.CreatedUser, ParameterDirection.Input);
            parms[13] = DataProxy.GetParameter("@ModifiedUsers", article.ModifiedUser, ParameterDirection.Input);
            parms[14] = DataProxy.GetParameter("@ReturnId",0, ParameterDirection.Output);
            int returnValue = DataProxy.ExecuteNonQuery("p_ins_article", ref parms);

            article.Id = int.Parse(parms[14].Value.ToString());
        }

        public void SetArticleStatus(Guid uniqueId, int statusCode)
        {
            SqlParameter[] parms = new SqlParameter[2];

            parms[0] = DataProxy.GetParameter("@UniqueId", uniqueId, ParameterDirection.Input);
            parms[1] = DataProxy.GetParameter("@StatusCode",statusCode , ParameterDirection.Input);
            int returnValue = DataProxy.ExecuteNonQuery("p_update_article_status", ref parms);
        }

        public void SetAssgnedTo(Guid uniqueId, string userName)
        {
            SqlParameter[] parms = new SqlParameter[2];

            parms[0] = DataProxy.GetParameter("@UniqueId", uniqueId, ParameterDirection.Input);
            parms[1] = DataProxy.GetParameter("@UserName", userName, ParameterDirection.Input);
            int returnValue = DataProxy.ExecuteNonQuery("p_update_Assigned", ref parms);
        }


        public Article GetArticle(Guid uniqueId)
        {
            SqlParameter[] parms = new SqlParameter[1];

            parms[0] = DataProxy.GetParameter("@UniqueId", uniqueId, ParameterDirection.Input);
            DataTable dataTable = new DataTable();
            DataProxy.Fill(dataTable, "p_get_article", parms);

            if (DataCommon.TableHasRows(dataTable))
            {
                   return new Article(dataTable.Rows[0]);
            }
            return null;
        }

        public List<ArticleStatus> GetArticleStatuses(string userId)
        {
            SqlParameter[] parms = new SqlParameter[1];

            parms[0] = DataProxy.GetParameter("@userid",userId, ParameterDirection.Input);
            DataTable dataTable = new DataTable();
            DataProxy.Fill(dataTable, "p_get_article_status_by_userid", parms);
            List<ArticleStatus> statuses = new List<ArticleStatus>();
            if (DataCommon.TableHasRows(dataTable))
            {
                foreach (DataRow row in dataTable.Rows)
                {
                    ArticleStatus status = new ArticleStatus();
                    status.ID = int.Parse(row["id"].ToString());
                    status.Description = row["Description"].ToString();
                    statuses.Add(status);
                }
            }
            return statuses;
        }

        public List<Article> GetArticles(string userName, int resultCount)
        {
            SqlParameter[] parms = new SqlParameter[2];

            parms[0] = DataProxy.GetParameter("@UserName", userName, ParameterDirection.Input);
            parms[1] = DataProxy.GetParameter("@Count", resultCount, ParameterDirection.Input);
            DataTable dataTable = new DataTable();
            DataProxy.Fill(dataTable, "p_get_articles", parms);

            List<Article> articles = new List<Article>();
            if (DataCommon.TableHasRows(dataTable))
            {
                foreach (DataRow row in dataTable.Rows)
                {
                    articles.Add(new Article(row));
                }
            }
            return articles;
        }
    }
}
