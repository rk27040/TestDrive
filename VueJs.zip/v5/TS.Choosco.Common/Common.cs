﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TS.Choosco.Common
{
    public enum ArticleStatus
    {
        None = 1,
        Active = 2,
        Open = 3,
        ReadyToPublish= 4,
        ProofReading = 5,
        Deleted = 6,
        Archived = 7
    }
}
