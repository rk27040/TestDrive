﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using WebApplication5.Models;

namespace WebApplication5.Controllers.DAL
{
    public class EventDAL
    {
        private String Connectionstring = string.Empty;

        public EventDAL()
        {
            Connectionstring = ConfigurationManager.ConnectionStrings["ConectionString"].ToString();
        }

        public Event Get()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(Connectionstring))
                {
                    string commandText = "GetEvent";
                    using (SqlCommand cmd = new SqlCommand(commandText, conn))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        if (conn.State == System.Data.ConnectionState.Closed)
                            conn.Open();
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            return new Event()
                            {
                                CONTENT = reader["CONTENT"].ToString(),
                                GUID = reader["GUID"].ToString(),
                                HEADER = reader["HEADER"].ToString(),
                                SUBHEADER = reader["SUBHEADER"].ToString(),
                                MAINIMAGE = reader["MAINIMAGE"].ToString(),
                                THUMBNAIL = reader["THUMBNAIL"].ToString(),
                                LARGEIMAGE = reader["LARGEIMAGE"].ToString()
                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return null;
            }
            return new Event();
        }

        public bool InsertEvent(Event _event)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(Connectionstring))
                {
                    string commandText = "InsertEvent";
                    using (SqlCommand cmd = new SqlCommand(commandText, conn))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@GUID", _event.GUID);
                        cmd.Parameters.AddWithValue("@HEADER", _event.HEADER);
                        cmd.Parameters.AddWithValue("@SUBHEADER", _event.SUBHEADER);
                        cmd.Parameters.AddWithValue("@CONTENT", _event.CONTENT);
                        cmd.Parameters.AddWithValue("@MAINIMAGE", _event.MAINIMAGE);
                        cmd.Parameters.AddWithValue("@THUMBNAIL", _event.THUMBNAIL);
                        cmd.Parameters.AddWithValue("@LARGEIMAGE", _event.LARGEIMAGE);
                        if (conn.State == System.Data.ConnectionState.Closed)
                            conn.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}