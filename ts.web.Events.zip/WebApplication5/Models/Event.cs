﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication5.Models
{
    public class Event
    {
        public Event()
        {
            this.GUID = Guid.NewGuid().ToString();
        }

        public int Id { get; set; }
        public string GUID { get; set; }
        public string HEADER { get; set; }
        public string SUBHEADER { get; set; }
        public string CONTENT { get; set; }
        public string THUMBNAIL { get; set; }
        public string MAINIMAGE { get; set; }
        public string LARGEIMAGE { get; set; }
        public bool ISACTIVE { get; set; }
    }
}