﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using TS.Choosco.Common.Entities;


namespace TS.Choosco.DAL
{
    public static class UserDB
    {
        public static List<string> GetUsersList()
        {
            List<string> users = new List<string>();
            DataTable dataTable = new DataTable();
            DataProxy.Fill(dataTable, "p_get_users_list");
            List<ArticleStatus> statuses = new List<ArticleStatus>();
            if (DataCommon.TableHasRows(dataTable))
            {
                foreach (DataRow row in dataTable.Rows)
                {
                    users.Add(row["UserName"].ToString());
                }
            }
            return users;
        }
    }
}
