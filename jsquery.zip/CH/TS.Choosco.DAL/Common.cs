﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Xml;

namespace TS.Choosco.DAL
{
    public static class DataCommon
    {
        public const string APOSTROPHE = "'";
        public const string BACKSLASH = "\\";
        public const string CHAR_0 = "0";
        public const string CHAR_9 = "9";
        public const string COMMA = ",";
        public const string DATE_MASK_MDY = "MM/dd/yyyy";
        public const string DATE_MASK_YMD = "yyyy-MM-dd";
        public const string DASH = "-";
        public const string DOLLAR_SIGN = "$";
        public const string EQUAL_SIGN = "=";
        public const string LEFT_PARENTHESIS = "(";
        public const string PERIOD = ".";
        public const string PIPE = "|";
        public const char PIPE_DELIM = '|';
        public const string RIGHT_PARENTHESIS = ")";
        public const string SINGLE_QUOTE = "'";
        public const string SINGLE_QUOTE_X2 = "'";
        public const string SPACE = " ";
        public const char TILDE_DELIM = '~';
        public const string TIME_MASK_HMS = "hh:mm:ss";
        public const string TRUE_1 = "1";
        public const string TRUE_TRUE = "true";
        public const string TRUE_Y = "y";
        public const string TRUE_YES = "yes";
        public const string UNDERSCORE = "_";
        public const string N_FLG = "N";
        public const string Y_FLG = "Y";


        public static bool IsNull(object val)
        {
            if (val == null) return true;
            if (val == System.DBNull.Value) return true;
            var prop = val.GetType().GetProperty("IsNull", typeof(System.Boolean));

            if (prop != null)
            {
                bool isNull = (bool)val.GetType().InvokeMember("IsNull", System.Reflection.BindingFlags.GetProperty, null, val, null);
                if (isNull) return true;
            }
            return false;
        }

        public static bool TableHasRows(DataTable table)
        {
            if (table == null) return false;
            if (table.Rows.Count > 0)
            { return true; }
            else
            { return false; }
        }

        public static bool IsEqual(string val1, string val2)
        {
            if ((val1 != null) & (val2 != null))
            {
                if (val1.ToUpper() == val2.ToUpper()) return true;
            }

            return false;
        }



        public static bool ToBool(string val)
        {
            if (!String.IsNullOrEmpty(val))
            {
                val = val.ToLower();

                if (val == TRUE_TRUE |
                    val == TRUE_YES |
                    val == TRUE_Y |
                    val == TRUE_1) return true;
            }

            return false;
        }


        public static DateTime ToDate(string val)
        {
            if (!String.IsNullOrEmpty(val))
            {
                DateTime wkDt = DateTime.MinValue;

                if (DateTime.TryParse(val, out wkDt))
                { return wkDt; }
            }

            return DateTime.MinValue;
        }

        //================================================================================
        // TO DECIMAL
        //================================================================================
        public static decimal ToDecimal(object val)
        {
            if (!IsNull(val))
            {
                return ToDecimal(val.ToString());
            }

            return 0;
        }

        public static decimal ToDecimal(string val)
        {
            if (!String.IsNullOrEmpty(val))
            {
                decimal wkDecimal = 0;

                if (decimal.TryParse(val, out wkDecimal))
                { return wkDecimal; }
            }

            return 0;
        }

        public static decimal ToDecimal(XmlAttribute val)
        {
            if (val != null)
            { return ToDecimal(val.InnerText); }

            return 0;
        }

        public static decimal ToDecimal(XmlNode val)
        {
            if (val != null)
            { return ToDecimal(val.InnerText); }

            return 0;
        }

        //================================================================================
        // TO DOUBLE
        //================================================================================
        public static double ToDouble(object val)
        {
            if (!IsNull(val))
            {
                return ToDouble(val.ToString());
            }

            return 0;
        }

        public static double ToDouble(string val)
        {
            if (!String.IsNullOrEmpty(val))
            {
                double wkDouble = 0;

                if (Double.TryParse(val, out wkDouble))
                { return wkDouble; }
            }

            return 0;
        }

        public static double ToDouble(string val, string delim)
        {
            val = ToString(val, delim);

            if (!String.IsNullOrEmpty(val))
            {
                double wkDouble = 0;

                if (Double.TryParse(val, out wkDouble))
                { return wkDouble; }
            }

            return 0;
        }

        public static double ToDouble(XmlAttribute val)
        {
            if (val != null)
            { return ToDouble(val.InnerText); }

            return 0;
        }

        public static double ToDouble(XmlNode val)
        {
            if (val != null)
            { return ToDouble(val.InnerText); }

            return 0;
        }


        public static Guid ToGuid(object val)
        {
            if (!IsNull(val))
            {
                return new Guid(val.ToString());
            }

            return new Guid();
        }


        public static Int16 ToInt16(object val)
        {
            if (!IsNull(val))
            {
                return ToInt16(val.ToString());
            }

            return 0;
        }

        public static Int16 ToInt16(string val)
        {

            if (!String.IsNullOrEmpty(val))
            {
                Int16 wkInt = 0;

                if (Int16.TryParse(val, out wkInt))
                {
                    return wkInt;
                }
            }

            return 0;
        }

        public static Int16 ToInt16(string val, Int16 dflt)
        {

            if (!String.IsNullOrEmpty(val))
            {
                Int16 wkInt = 0;

                if (Int16.TryParse(val, out wkInt))
                { return wkInt; }
            }

            return dflt;
        }

        public static Int16 ToInt16(XmlAttribute val)
        {
            if (val != null)
            { return ToInt16(val.InnerText); }

            return 0;
        }

        public static Int16 ToInt16(XmlNode val)
        {
            if (val != null)
            { return ToInt16(val.InnerText); }

            return 0;
        }


        public static Int32 ToInt32(object val)
        {
            if (!IsNull(val))
            {
                return ToInt32(val.ToString());
            }

            return 0;
        }

        public static Int32 ToInt32(string val)
        {

            if (!String.IsNullOrEmpty(val))
            {
                Int32 wkInt = 0;

                if (Int32.TryParse(val, out wkInt))
                { return wkInt; }
            }

            return 0;
        }

        public static Int32 ToInt32(string val, string delim)
        {
            val = ToString(val, delim);

            if (!String.IsNullOrEmpty(val))
            {
                Int32 wkInt = 0;

                if (Int32.TryParse(val, out wkInt))
                { return wkInt; }
            }

            return 0;
        }

        public static Int32 ToInt32(XmlAttribute val)
        {
            if (val != null)
            { return ToInt32(val.InnerText); }

            return 0;
        }

        public static Int32 ToInt32(XmlNode val)
        {
            if (val != null)
            { return ToInt32(val.InnerText); }

            return 0;
        }


        public static Int64 ToInt64(object val)
        {
            if (!IsNull(val))
            {
                return ToInt64(val.ToString());
            }

            return 0;
        }

        public static Int64 ToInt64(string val)
        {
            if (!String.IsNullOrEmpty(val))
            {
                Int64 wkInt = 0;

                if (Int64.TryParse(val, out wkInt))
                { return wkInt; }
            }

            return 0;
        }

        public static Int64 ToInt64(string val, string delim)
        {
            val = ToString(val, delim);

            if (!String.IsNullOrEmpty(val))
            {
                Int64 wkInt = 0;

                if (Int64.TryParse(val, out wkInt))
                { return wkInt; }
            }

            return 0;
        }

        public static Int64 ToInt64(XmlAttribute val)
        {
            if (val != null)
            { return ToInt64(val.InnerText); }

            return 0;
        }

        public static Int64 ToInt64(XmlNode val)
        {
            if (val != null)
            { return ToInt64(val.InnerText); }

            return 0;
        }




        //================================================================================
        // TO STRING
        //================================================================================
        public static string ToString(object val)
        {
            if (!IsNull(val))
            {
                return val.ToString();
            }

            return null;
        }

        public static string ToString(string val, Int32 maxLen)
        {
            if (!String.IsNullOrEmpty(val))
            {
                if (maxLen <= 0) return String.Empty;

                if (val.Length <= maxLen)
                { return val.Trim(); }
                else
                { return val.Substring(0, maxLen).Trim(); }
            }

            return null;
        }

        public static string ToString(string val, string delim)
        {
            if (!String.IsNullOrEmpty(val))
            {
                if (!String.IsNullOrEmpty(delim))
                {
                    int idx = val.IndexOf(delim);

                    if (idx > 0)
                    { return val.Substring(0, idx); }
                    else if (idx == 0)
                    { return String.Empty; }
                    else
                    { return val; }
                }
            }

            return null;
        }

        public static string ToString(XmlAttribute val)
        {
            if (val != null) return val.InnerText;

            return null;
        }

        public static string ToString(XmlNode val)
        {
            if (val != null) return val.InnerText;

            return null;
        }

        public static string ToString(XmlNode val, string defaultValue)
        {
            string result = defaultValue;

            if (val != null)
            {
                result = val.InnerText;
            }

            return result;
        }


        public static List<string> ToStringList(object val)
        {
            if (!IsNull(val))
            {
                System.Array sysArray = val as System.Array;

                if ((sysArray != null))
                {
                    Int32 len = sysArray.Length;

                    if (len > 0)
                    {
                        List<string> strList = new List<string>();

                        foreach (object obj in sysArray)
                        {
                            if ((obj != null))
                            { strList.Add(obj.ToString().Trim()); }
                        }

                        return strList;
                    }
                }
            }

            return null;
        }


        public static string ToYN(bool val)
        {
            if (!val) return N_FLG;
            return Y_FLG;
        }

        public static string Trim(string val)
        {
            if (!String.IsNullOrEmpty(val)) return val.Trim();

            return String.Empty;
        }

        public static string Trim(string val, Int32 maxLen)
        {
            if (!String.IsNullOrEmpty(val))
            {
                if (val.Length > maxLen) return val.Substring(0, maxLen).Trim();

                return val.Trim();
            }

            return String.Empty;
        }
    }

}
